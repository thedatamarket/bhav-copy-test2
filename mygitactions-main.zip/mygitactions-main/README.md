# mygitactions

This is for the YouTube Tutorial: <https://www.youtube.com/watch?v=mFFXuXjVgkU>

## Updates
Fix: Changed SuperLinter from v3 to v4 to fix the error `[FATAL] Failed to view version file:[/action/lib/functions/linterVersions.txt]`
